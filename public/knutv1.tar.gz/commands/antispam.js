import { statusProtections } from "../protections.js";

export const name = "antispam";

const userMessages = {};

const SPAM_LIMIT = 5;

const SPAM_TIME_WINDOW = 10_000;

export function setupAntiSpam(sock) {

  sock.ev.on("messages.upsert", async ({ messages }) => {

    if (!statusProtections.antiSpam) return;

    const msg = messages[0];

    if (!msg.message) return;

    if (!msg.key.remoteJid.endsWith("@g.us")) return;

    const from = msg.key.remoteJid;

    const sender = msg.key.participant || msg.key.remoteJid;

    // Ignorer les bots et le owner

    if (sender.includes("bot") || statusProtections.owners.includes(sender)) return;

    const now = Date.now();

    if (!userMessages[sender]) userMessages[sender] = [];

    userMessages[sender].push({ key: msg.key, timestamp: now });

    userMessages[sender] = userMessages[sender].filter(m => now - m.timestamp <= SPAM_TIME_WINDOW);

    if (userMessages[sender].length >= SPAM_LIMIT) {

      try {

        for (const m of userMessages[sender]) {

          if (!m.key.fromMe) await sock.sendMessage(from, { delete: m.key });

        }

        await sock.sendMessage(from, {

        text: `> Knut MD : @${sender.split("@")[0]} tentative de spam détectée`,

          mentions: [sender]

        });

        console.log(`[ANTISPAM] Messages de ${sender} supprimés dans ${from}`);

      } catch (e) {

        console.error("Erreur Antispam:", e);

      } finally {

        userMessages[sender] = [];

      }

    }

  });

}

// Commande pour activer/désactiver l'anti-spam

export async function execute(sock, msg, args) {

  const from = msg.key.remoteJid;

  if (!args[0] || !["on", "off"].includes(args[0])) {

    await sock.sendMessage(from, {

      text: `> Knut MD : AntiSpam est ${statusProtections.antiSpam ? "actif" : "inactif"}\nUsage : !antispam <on/off>`

    });

    return;

  }

  statusProtections.antiSpam = args[0] === "on";

  await sock.sendMessage(from, {

    text: `> Knut MD : Anti-spam ${args[0] === "on" ? "actif" : "inactif"} !`

  });

}