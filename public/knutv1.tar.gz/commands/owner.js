export const name = "owner";

export async function execute(sock, msg, args) {
  const from = msg.key.remoteJid;

  // Texte principal
  const text = `╭━━━━━━•⊰⚫⊱•━━━━━━╮
       KNUT  MD
╰━━━━━━•⊰⚫⊱•━━━━━━╯
╭─────•⊰ DEV BY KNUT ⊱•───────            │ 🕷️👁️‍🗨️ Rejoins-nous 👁️‍🗨️🕷️                    │ 🖤 WhatsApp knut: - 237683939081
│ 🖤 WhatsApp 𝐙𝐊⚚𝐌𝐒𝟔 237640483144
│ 🖤 Telegram : t.me/Devknut         
╰────•⊰ Canaux officiels ⊱•────
│ 🕯️ WhatsApp : https://whatsapp.com/channel/0029VbBezz33LdQaHgOdm22n 
│ 🕯️ Telegram : https://t.me/knutMDX        ╰━━━──━━━•⊰⚫⊱•━━━━──━━╯`;

  // Envoi du message
  await sock.sendMessage(from, { text }, { quoted: msg });
}