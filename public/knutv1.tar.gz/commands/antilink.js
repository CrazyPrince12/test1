// commands/antilink.js

import { statusProtections } from "../protections.js";

export const name = "antilink";

export async function execute(sock, msg, args) {

  const from = msg.key.remoteJid;

  // Activation / désactivation de l'anti-link

  if (!args[0] || !["on","off"].includes(args[0])) {

    await sock.sendMessage(from, {

      text: `> Knut MD: Anti-link est ${statusProtections.antiLink ? "actif" : "inactif"}\nUsage : .antilink <on/off>`

    });

    return;

  }

  statusProtections.antiLink = args[0] === "on";

  await sock.sendMessage(from, {

    text: `> Knut MD : Anti-link ${args[0] === "on" ? "actif" : "inactif"} !`

  });

}

// Détection et suppression des liens

export function antiLink(sock) {

  sock.ev.on("messages.upsert", async ({ messages }) => {

    if (!statusProtections.antiLink) return;

    const msg = messages[0];

    if (!msg.message) return;

    const from = msg.key.remoteJid;

    const sender = msg.key.participant || from;

    const text = msg.message.conversation

               || msg.message.extendedTextMessage?.text

               || msg.message.imageMessage?.caption

               || msg.message.videoMessage?.caption;

    if (!text) return;

    // Regex pour détecter tous les liens

    const linkRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|chat\.whatsapp\.com\/[^\s]+|t\.me\/[^\s]+|bit\.ly\/[^\s]+)/gi;

    if (!linkRegex.test(text)) return;

    try {

      // Supprimer le message si ce n'est pas le bot et que c'est un groupe

      if (!msg.key.fromMe && from.endsWith("@g.us")) {

        await sock.sendMessage(from, {

          text: `╭═════۞ KNUT MDX V2 ۞═════╮\n` +
     `🌘 KNUT MDX 2.0 🖤\n` +             `╰═════۞════════════╯\n\n` +
`╭═══🛡️ ANTI-LINK 🛡️═══╮\n` +
`│ ⚠️ @${sender.split("@")[0]}, les liens sont interdits dans ce groupe !\n`+               `╰════════════════════╯\n\n` +
`> Dev Knut`,

          mentions: [sender]

        });

        await sock.sendMessage(from, { delete: msg.key });

      }

    } catch (e) {

      console.error("Erreur AntiLink:", e);

    }

  });

}