export const name = "tag";

export async function execute(sock, msg, args) {

  const from = msg.key.remoteJid;

  // Vérifie si c'est un groupe

  if (!from.endsWith("@g.us")) {

    return await sock.sendMessage(from, { text: "_⚫KNUT MDX☠️:_ *Commande réservée aux groupes seulement.*" }, { quoted: msg });

  }

  try {

    const groupMetadata = await sock.groupMetadata(from);

    const participants = groupMetadata.participants;

    const mentions = participants.map(p => p.id);

    let message;

    // 1️⃣ Si l'utilisateur a fourni un texte après la commande

    if (args.length) {

      message = args.join(" ");

    } 

    // 2️⃣ Si l'utilisateur répond à un message

    else if (msg.message?.extendedTextMessage?.text) {

      message = msg.message.extendedTextMessage.text;

    } 

    // 3️⃣ Aucun message → texte par défaut

    else {
      message = "🖤KNUT MDX🐺: Yo";
    }

    // Envoi du message avec mentions visibles

    await sock.sendMessage(

      from,

      {

        text: `\n\n${message}`,

        mentions

      },

      { quoted: msg }

    );

  } catch (e) {

    console.error("_⚫KNUT MDX☠️:_ ❌ Erreur commande tag :", e);

    await sock.sendMessage(from, { text: "_⚫KNUT MDX☠️:_ Erreur lors de l'envoi du tag." }, { quoted: msg });

  }

}