export const name = "purge";

export async function execute(sock, msg, args, options = {}) {

  const from = msg?.key?.remoteJid;

  const ownerNumber = (process.env.OWNER_NUMBER || "").replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  if (!from || !from.endsWith("@g.us")) {

    await sock.sendMessage(from || msg.key.remoteJid, { text: "> Knut MD : 🫩 Commande de groupe " }, { quoted: msg });

    return;

  }

  try {

    const groupData = await sock.groupMetadata(from);

    const participants = groupData.participants || [];

    const botJid = (sock?.user?.id || sock?.user?.jid || "").split?.(":")?.[0] || "";

    const toKick = participants

      .filter(p => !p.admin)

      .map(p => p.id)

      .filter(id => id !== botJid && id !== ownerNumber);

    if (toKick.length === 0) {

      await sock.sendMessage(from, { text: "> Knut MD :🫩 Aucun membre non-admin à expulser." }, { quoted: msg });

      return;

    }

    const allMembers = participants.map(p => p.id);

    // =================== COMPTE À REBOURS CINÉMATIQUE ===================

    const countdownEmojis = ["💀", "🔥", "☠️", "🩸", "🌪️"];

    for (let i = 5; i > 0; i--) {

      await sock.sendMessage(from, { text: `╭═══۞ KNUT MDX V2 ۞════╮\n🕷️ *Purge dans ${i}...* ${countdownEmojis[i % countdownEmojis.length]}\n╰════════════════╯`, mentions: allMembers });

      await new Promise(r => setTimeout(r, 1000)); // 1 seconde de pause

    }

    // =================== TEXTE HIDETAG DRAMATIQUE ===================

    const purgeText = `

╭══۞ KNUT MDX V2 ۞══╮
💀PURGE INÉLUCTABLE💀
╰════════════════╯

☠️ _Je ne viens pas en messager, mais en force primordiale._ ☠️  

💨 Chaque murmure d'opposition, chaque acte de résistance ne fera qu'alimenter le feu. 🔥  

🩸 Votre arrogance sera votre cendre, votre faiblesse sera votre châtiment. 💀

🌪️ La purification n'est pas un jugement, c'est une nécessité. ⚡  

🕷️ Une force primordiale qui balaie les impuretés pour que l'aube puisse enfin se lever sur un monde nouveau. 🌅

> Dev by Knut ⚛️🌘

`;

    await sock.sendMessage(from, { text: purgeText, mentions: allMembers });

    // =================== EXPULSION ===================

    await sock.groupParticipantsUpdate(from, toKick, "remove");

    await sock.sendMessage(from, { text: `> Knut MD: 😼  *Purge exécutée : ${toKick.length} membre(s) expulsé(s).*\n💀 Admin et owner protégés 💀` }, { quoted: msg });

  } catch (err) {

    console.error("❌ Erreur purge :", err);

    await sock.sendMessage(from, { text: "❌ *Erreur lors de la purge.* Vérifie mes permissions ou réessaye." }, { quoted: msg });

  }

}