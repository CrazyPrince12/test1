export const name = "menu";

export async function execute(sock, msg, args) {
  try {
    const from = msg.key.remoteJid;

    // Uptime du bot
    const totalSeconds = process.uptime();
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const uptime = `${hours}h ${minutes}m ${seconds}s`;

  const text = `╔════════════════════╗
       ⚫ KNUT MD⚫
╚════════════════════╝
🥷🏾 *Utilisateur* : ${msg.pushName || "Invité"}
⚙️ *Mode*        : 🔒 Privé
⏱️ *Uptime*      : ${uptime}
📱 *Version*     : 2.0
🧎🏾 *Développeur* : _Knut_
╔────── GROUPS ───────╗
➤ left
➤ gclink
➤ promote @
➤ demote @
➤ promoteall
➤ demoteall
➤ kick @
➤ kickall
➤ purge
➤ infosgroups
➤ tag
➤ tagall
➤ tagadmin
➤ mute
➤ unmute
╚───────────────────╝

╔────── SECURITY ─────╗
➤ principal
➤ antibot
➤ antidemote
➤ antipromote
➤ antispam
╚───────────────────╝

╔───── UTILITY ─────╗
➤ ping
➤ owner
➤ delete
➤ infos
➤ baiseall
╚──────────────────╝

╔─── MEDIAS & IA ────╗
➤ sticker
➤ take
➤ save
➤ photo
➤ gpt
╚─────────────────╝
> Dev  Knut`;

    // Envoi du GIF animé remplacé par le nouveau MP4
    await sock.sendMessage(
      from,
      {
        image: { url: "https://files.catbox.moe/1s5w0x.jpg" },
        caption: text,
        gifPlayback: true
      },
      { quoted: msg }
    );

    // Envoi de l'audio
    await sock.sendMessage(
      from,
      {
        audio: { url: "https://files.catbox.moe/yfe0a3.mp4" },
        mimetype: "audio/mpeg"
      },
      { quoted: msg }
    );

  } catch (err) {
    console.error("❌ Erreur commande menu :", err);
    await sock.sendMessage(
      msg.key.remoteJid,
      { text: "⚠️ Impossible d’afficher le menu." },
      { quoted: msg }
    );
  }
}