export const name = "baiseall";

export async function execute(sock, msg, args) {
  try {
    const from = msg.key.remoteJid;

    // Uptime du bot
    const totalSeconds = process.uptime();
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const uptime = `${hours}h ${minutes}m ${seconds}s`;

    const text = `╭═══════❖•°•❖═══════╮
     💀🍑 BAISE ALL💦💀
╰═══════❖•°•❖═══════╯

> 🌙 La nuit tombe… et le désir s’éveille 😈💦
Chaque regard brûle 🔥, chaque souffle tease 💋
Oses-tu franchir les portes interdites 🚪💫?

1️⃣https://fr.ok.xxx/search/xxx-porn/
2️⃣https://xxxz.tv/
3️⃣https://www.inxxx.com/
4️⃣https://www.youporn.com/
5️⃣https://fr.pornhub.com/
6️⃣https://fr.xvideos.com/tags/xxx-porn
7️⃣www.jedolo.com
8️⃣www.nsozut.com

> Baisons... La mort existe 💔🧎🏽‍♂️

╭═══════❖•°•❖═══════╮
 .     🖤 Knut MD 
╰═══════❖•°•❖═══════╯

> Dev by Knut`;

    // Envoi du GIF animé remplacé par le nouveau MP4
    await sock.sendMessage(
      from,
      {
        image: { url: "https://files.catbox.moe/o18xsa.jpg" },
        caption: text,
        gifPlayback: true
      },
      { quoted: msg }
    );

    // Envoi de l'audio
    await sock.sendMessage(
      from,
      {
        audio: { url: "https://files.catbox.moe/tg7tv6.mp3" },
        mimetype: "audio/mpeg"
      },
      { quoted: msg }
    );

  } catch (err) {
    console.error("❌ Erreur commande menu :", err);
    await sock.sendMessage(
      msg.key.remoteJid,
      { text: "⚠️ Impossible d’afficher le menu." },
      { quoted: msg }
    );
  }
}