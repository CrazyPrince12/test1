import chalk from "chalk";

// =================== CONFIG ===================

const blockedLinks = ["chat.whatsapp.com", "bit.ly", "t.me"];

const owners = []; // ajouter les numéros propriétaires ici

const autoLikeInterval = 60_000;

// =================== ETAT DES PROTECTIONS ===================

export const statusProtections = {

  antiLink: false,

  antiPromote: false,

  antiDemote: false,

  antiBot: true,

  autoLikeStatus: true,

  warnAdmin: false // 🔔 nouvelle protection activable/désactivable

};

// =================== FONCTIONS ===================

// Anti-Link

export function antiLink(sock) {

  sock.ev.on("messages.upsert", async ({ messages }) => {

    if (!statusProtections.antiLink) return;

    const msg = messages[0];

    if (!msg.message) return;

    const from = msg.key.remoteJid;

    const text = msg.message.conversation

                 || msg.message.extendedTextMessage?.text

                 || msg.message.imageMessage?.caption

                 || msg.message.videoMessage?.caption;

    if (!text) return;

    try {

      const groupMetadata = from.endsWith("@g.us") ? await sock.groupMetadata(from) : null;

      const sender = msg.key.participant || from;

      const isAdmin = groupMetadata?.participants?.find(p => p.id === sender)?.admin;

      if (owners.includes(sender) || isAdmin) return;

      for (const link of blockedLinks) {

        if (text.includes(link)) {

          await sock.sendMessage(from, { text: `> Knut MD : ⚠️ Lien(s) détecté(s)! @${sender.split("@")[0]}` , mentions: [sender] });

          if (!msg.key.fromMe && from.endsWith("@g.us")) await sock.sendMessage(from, { delete: msg.key });

          console.log(chalk.yellow(`[ANTI-LINK] Message supprimé de ${sender} dans ${from}`));

          return;

        }

      }

    } catch (e) { console.error(e); }

  });

}

// WarnAdmin

export function warnAdmin(sock) {

  sock.ev.on("group-participants.update", async (update) => {

    if (!statusProtections.warnAdmin) return; // ✅ seulement si activé

    try {

      const groupId = update.id;

      const groupMetadata = await sock.groupMetadata(groupId);

      if (update.action === "promote" || update.action === "demote") {

        for (const participant of update.participants) {

          const tag = `@${participant.split("@")[0]}`;

          const actionText = update.action === "promote"

            ? `👑 ${tag} a été *promu admin* !`

            : `⚠️ ${tag} a été *rétrogradé* !`;

          const text = `╭═══🖤🐺 KNUT MDX 🐺🖤════╮
    ⚔️ *ALERTE ADMIN* ⚔️
╰══════════════════════╯
📌 Groupe : *${groupMetadata.subject}*
${actionText}
> Dev Knut🖤`;

          await sock.sendMessage(groupId, { text, mentions: [participant] });

        }

      }

    } catch (err) {

      console.error("[WARNADMIN] Erreur :", err);

    }

  });

}

// Commande pour activer/désactiver protections depuis le chat

export function protectCommand(sock) {

  sock.ev.on("messages.upsert", async ({ messages }) => {

    const msg = messages[0];

    if (!msg.message) return;

    const from = msg.key.remoteJid;

    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

    if (!text || !text.startsWith("!protect")) return;

    const args = text.trim().split(/ +/).slice(1);

    if (args.length === 0) {

      const statusText = Object.entries(statusProtections)

        .map(([key, val]) => `• ${key}: ${val ? "✅" : "❌"}`)

        .join("\n");

      await sock.sendMessage(from, { text: `Etat de sécurité :\n${statusText}` });

      return;

    }

    const [action, feature] = args;

    if (!["on","off"].includes(action) || !Object.keys(statusProtections).includes(feature)) {

      await sock.sendMessage(from, { text: "> Knut MD : Utilisation : !protect <on/off> <antiLink|antiPromote|antiDemote|antiBot|autoLikeStatus|warnAdmin>" });

      return;

    }

    statusProtections[feature] = action === "on";

    await sock.sendMessage(from, { text: `> Knut MD : Protection ${feature} ${action === "on" ? "activée ✅" : "désactivée ❌"} !` });

  });

}

// =================== INIT ===================

export function initProtections(sock) {

  antiLink(sock);

  warnAdmin(sock); // 🔔 activation warnAdmin

  protectCommand(sock); // commande !protect

}