export const name = "menu";

export async function execute(sock, msg, args) {

  try {

    const from = msg.key.remoteJid;

    // Uptime du bot

    const totalSeconds = process.uptime();

    const hours = Math.floor(totalSeconds / 3600);

    const minutes = Math.floor((totalSeconds % 3600) / 60);

    const seconds = Math.floor(totalSeconds % 60);

    const uptime = `${hours}h ${minutes}m ${seconds}s`;

const text = `> ╔════════════════════╗
        ⚫ KNUT-XMD ⚫
> ╚════════════════════╝
> 𝐼'𝑚 𝑐𝑟𝑎𝑧𝑦....𝑚𝑎𝑦𝑏𝑒

> 🥷🏾 *Utilisateur* : ${msg.pushName || "Invité"}
> ⚙️ *Mode*        : 🔒 Privé
> ⏱️ *Uptime*      : ${uptime}
> 📱 *Version*     : 3.0
> 🧎🏾 *Développeur* : _Knut_

> ╔──────XMD───────╗
> ➤ bugmenu 
> ╚────────────────╝

> ╔────── IA ──────╗
> ➤ knut (question)
> ➤ imagine 
> ➤ k-video 
> ➤ ai
> ➤ knutchat
> ➤ knutchat-ib
> ╚────────────────╝

> ╔──── UTILITY ─────╗
> ➤ prefix
> ➤ delete
> ➤ vv
> ➤ device
> ➤ countryinfos
> ➤ infos
> ➤ take
> ➤ meteo
> ➤ lyrics 
> ➤ ping
> ➤ whois
> ➤ autoreact
> ➤ setpp
> ╚─────────────────╝

> ╔────── SUDO ──────╗
> ➤ delsudo
> ➤ listsudo
> ➤ setsudo
> ╚─────────────────╝

> ╔───── GROUPS ─────╗
> ➤ add
> ➤ demote @
> ➤ demoteall
> ➤ gclink
> ➤ infosgroups
> ➤ kick @
> ➤ kickall
> ➤ left
> ➤ mute
> ➤ unmute
> ➤ mute-time
> ➤ promote @
> ➤ promoteall
> ➤ purge
> ➤ principal 
> ➤ setppg
> ➤ settimeg 
> ➤ tag
> ➤ tagadmin
> ➤ tagall
> ➤ writetoall
> ➤ wasted
> ➤ welcome 
> ➤ goodbye 
> ╚──────────────────╝

> ╔──── DOWNLOAD ────╗
> ➤ img
> ➤ play
> ➤ apk
> ➤ tiktok
> ➤ Instagram 
> ➤ down-url
> ➤ url
> ➤ youtube 
> ➤ yt
> ➤ telegram-sticker
> ╚──────────────────╝

> ╔───── SECURITY ─────╗
> ➤ antibot
> ➤ antilink
> ➤ antimessage 
> ➤ antivoice 
> ➤ antiaudio 
> ➤ antisticker 
> ╚───────────────────╝

> ╔───── MEDIAS ─────╗
> ➤ photo
> ➤ save
> ➤ sticker
> ╚──────────────────╝
> ╔─────────FUN───────╗
> ➤ anime
> ➤ baiseall
> ➤ blur
> ➤ hentai
> ➤ xvid
> ➤ xxx
> ╚───────────────────╝

> Dev  Knut`;

    // Envoi du menu avec image

    await sock.sendMessage(

      from,

      {

        image: { url: "https://files.catbox.moe/8dheuf.jpg" },

        caption: text,

        gifPlayback: true

      },

      { quoted: msg }

    );

    // Envoi de l'audio

    await sock.sendMessage(

      from,

      {

        audio: { url: "https://files.catbox.moe/fa0fiv.mp4" },

        mimetype: "audio/mpeg"

      },

      { quoted: msg }

    );

  } catch (err) {

    console.error("❌ Erreur commande menu :", err);

    await sock.sendMessage(

      msg.key.remoteJid,

      { text: "> ⚠️ Impossible d’afficher le menu." },

      { quoted: msg }

    );

  }

}