export const name = "left";

export async function execute(sock, msg, args) {
  try {
    await sock.sendMessage(msg.key.remoteJid, { text: "> Knut XMD: 𝐼'𝑚 𝑐𝑟𝑎𝑧𝑦....𝑚𝑎𝑦𝑏𝑒..." });
    await sock.groupLeave(msg.key.remoteJid);
  } catch (err) {
    console.error("❌ Erreur leave :", err);
  }
}