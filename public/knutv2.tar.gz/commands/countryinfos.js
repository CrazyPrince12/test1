export const name = "countryinfos";

export async function execute(sock, msg, args) {
  const from = msg.key.remoteJid;

  try {
    const countryName = args.join(" ").trim();

    if (!countryName) {
      return await sock.sendMessage(from, {
        text: "> ⚠️ KNUT MD : Fournis le nom d'un pays.\nExemple : .countryinfo Pakistan",
      }, { quoted: msg });
    }

    // Message de progression
    await sock.sendMessage(from, {
      text: "> 🌍 KNUT MD : Récupération des informations du pays..."
    }, { quoted: msg });

    // Requête API
    const apiUrl = `https://api.siputzx.my.id/api/tools/countryInfo?name=${encodeURIComponent(countryName)}`;
    const res = await fetch(apiUrl);
    const data = await res.json();

    if (!data || !data.status || !data.data) {
      return await sock.sendMessage(from, {
        text: `> ⚠️ KNUT MD : Aucune information trouvée pour *${countryName}*. Vérifie le nom du pays.`
      }, { quoted: msg });
    }

    const info = data.data;

    const neighborsText = info.neighbors.length > 0
      ? info.neighbors.map(n => `🌍 ${n.name}`).join(", ")
      : "Aucun pays voisin trouvé.";

    const caption = `> ╭════۩۞۩════╮
> ⚫ KNUT MD — COUNTRY INFO
> ╰════۩۞۩════╯
> ╭═🌍 INFORMATIONS══╮
> │ 🏛 Capitale : ${info.capital || "Inconnue"}
> │ 📍 Continent : ${info.continent.name || "Inconnu"} ${info.continent.emoji || ""}
> │ 📞 Indicatif : ${info.phoneCode || "N/A"}
> │ 📏 Superficie : ${info.area.squareKilometers} km² (${info.area.squareMiles} mi²)
> │ 🚗 Côté conduite : ${info.drivingSide || "N/A"}
> │ 💱 Monnaie : ${info.currency || "N/A"}
> │ 🔤 Langues : ${info.languages.native.join(", ") || "N/A"}
> │ 🌟 Connu pour : ${info.famousFor || "N/A"}
> │ 🌍 Codes ISO : ${info.isoCode.alpha2.toUpperCase()}, ${info.isoCode.alpha3.toUpperCase()}
> │ 🌎 Domaine internet : ${info.internetTLD || "N/A"}
> ╰════════════════╯
> 🔗 Pays voisins : ${neighborsText}

> Dev by Knut `;

    // Envoi avec le drapeau
    await sock.sendMessage(from, {
      image: { url: info.flag },
      caption
    }, { quoted: msg });

  } catch (err) {
    console.error("❌ Erreur countryinfo :", err);
    await sock.sendMessage(from, {
      text: `> ⚠️ KNUT MD : Une erreur est survenue lors de la récupération des informations.\nDétails : ${err.message}`
    }, { quoted: msg });
  }
}