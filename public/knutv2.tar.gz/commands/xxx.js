import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';

export const name = "xxx";

export async function execute(sock, msg, args, { lann }) {
    const from = msg.key.remoteJid;

    try {
        if (!args[0]) {
            return await sock.sendMessage(from, {
                text: '> ⚠️ KNUT MD: Veuillez fournir une URL.\nExemple: .sshp https://example.com'
            }, { quoted: msg });
        }

        // Vérification des liens interdits
        if (args[0].match(/xnxx\.com|hamster\.com|nekopoi\.care/i)) {
            return await sock.sendMessage(from, {
                text: '> ⚠️ KNUT MD: Ce lien est interdit !'
            }, { quoted: msg });
        }

        await sock.sendMessage(from, { text: '_Ｌｏａｄｉｎｇ．．._' }, { quoted: msg });

        // Préparer l'URL
        let url = args[0].startsWith('http') ? args[0] : 'https://' + args[0];

        // Requête API pour screenshot
        let response = await fetch(`https://api.betabotz.eu.org/api/tools/ssweb?url=${url}&device=phone&apikey=${lann}`);
        if (!response.ok) {
            return await sock.sendMessage(from, {
                text: '> ⚠️ KNUT MD: Impossible de récupérer le screenshot.'
            }, { quoted: msg });
        }

        // Créer le dossier tmp s'il n'existe pas
        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

        const filepath = path.join(tmpDir, `${Date.now()}.jpeg`);
        const dest = fs.createWriteStream(filepath);

        response.body.pipe(dest);

        dest.on('finish', async () => {
            try {
                await sock.sendMessage(from, {
                    document: { url: filepath },
                    fileName: 'screenshot.jpeg',
                    mimetype: 'image/jpeg',
                    caption: '🖼️ Voici votre screenshot !'
                }, { quoted: msg });

                // Optionnel : supprimer le fichier après envoi
                fs.unlinkSync(filepath);
            } catch (err) {
                console.error("❌ SSH Screenshot Send Error:", err);
            }
        });

        dest.on('error', (err) => {
            console.error("❌ SSH Screenshot Write Error:", err);
        });

    } catch (err) {
        console.error("❌ SSH Screenshot Error:", err);
        await sock.sendMessage(from, {
            text: `⚠️ KNUT MD: Une erreur est survenue lors de la récupération du screenshot.\nRaison: ${err.message || 'Erreur inconnue'}`
        }, { quoted: msg });
    }
}