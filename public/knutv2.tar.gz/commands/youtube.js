import axios from "axios";

export const name = "youtube";

export async function execute(sock, msg, args) {
  const from = msg.key.remoteJid;
  const url = args[0];

  // Vérification de l'argument
  if (!url || !url.startsWith("http")) {
    await sock.sendMessage(from, {
      text: "> Knut MD : Envoie un lien YouTube valide pour lancer le téléchargement 🎵",
      quoted: msg
    });
    return;
  }

  try {
    // Message initial
    const loadingMsg = await sock.sendMessage(from, {
      text: `> Knut MD : 🔎 Connexion à YouTube...`,
      quoted: msg
    });

    // Étapes simulées de chargement
    await new Promise(r => setTimeout(r, 1500));
    await sock.sendMessage(from, { text: "> Knut MD : 📡 Analyse du lien en cours...", quoted: loadingMsg });

    await new Promise(r => setTimeout(r, 1500));
    await sock.sendMessage(from, { text: "> Knut MD : 🎶 Récupération du fichier audio...", quoted: loadingMsg });

    // Appel de l’API Keith
    const response = await axios.get(`https://apis-keith.vercel.app/download/dlmp3?url=${encodeURIComponent(url)}`);

    if (!response.data || !response.data.status) {
      throw new Error("Impossible de récupérer l’audio à partir de ce lien.");
    }

    const result = response.data.result;
    if (!result || !result.title || !result.download_url) {
      throw new Error("Résultat audio incomplet ou lien invalide.");
    }

    // Message d’information
    const caption = 
`🎧 *Audio trouvé avec succès !*

📌 *Titre* : ${result.title}
⏱️ *Durée* : ${result.duration || "Inconnue"}
👁️ *Vues* : ${result.views || "N/A"}
🔗 *Lien source* : ${url}

📥 *Téléchargement de l’audio...*

> Knut MD 🖤`;

    await sock.sendMessage(from, {
      image: { url: result.thumbnail },
      caption,
      quoted: msg
    });

    // Envoi de l’audio
    await sock.sendMessage(from, {
      audio: { url: result.download_url },
      mimetype: "audio/mp4",
      ptt: false,
      quoted: msg
    });

  } catch (err) {
    console.error("Erreur play :", err);
    await sock.sendMessage(from, {
      text: `> Knut MD : ❌ Une erreur est survenue.\n⚠️ ${err.message}`,
      quoted: msg
    });
  }
}