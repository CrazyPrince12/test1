export const name = "ping";

export async function execute(sock, msg, args) {

  try {

    const from = msg.key.remoteJid;

    // Début test de latence

    const start = Date.now();

    const sentMsg = await sock.sendMessage(from, { text: "🫩 Ping..." }, { quoted: msg });

    const latency = Date.now() - start;

    // Réponse stylisée

    const reply = `> ╭═⚛️ PONG ⚛️══╮
> │ 🏎️ Bot opérationnel
> │ ⏱️ : ${latency} ms
> ╰═══════════╯`;

    await sock.sendMessage(from, { text: reply }, { quoted: sentMsg });

  } catch (err) {

    console.error("❌ Erreur ping :", err);

    await sock.sendMessage(msg.key.remoteJid, {

      text: "> ⚠️ KNUT MD: Impossible de calculer la vitesse."

    }, { quoted: msg });

  }

}