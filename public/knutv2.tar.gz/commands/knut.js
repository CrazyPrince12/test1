import axios from "axios";

export const name = "knut";

export async function execute(sock, msg, args) {

  try {

    const from = msg.key.remoteJid;

    const query = args.join(" ");

    // Vérification si une question est posée

    if (!query) {

      await sock.sendMessage(from, {

        text: `> Knut MD : *Usage incorrect...

Exemple : .knut combien de continent compte la Terre? ?`

      }, { quoted: msg });

      return;

    }

    // Message d’attente

    const sentMsg = await sock.sendMessage(from, {

      text: "> Knut MD : Chargement de la réponse..."

    }, { quoted: msg });

    // Appel API

    const apiUrl = `https://apis.davidcyriltech.my.id/ai/chatbot?query=${encodeURIComponent(query)}`;

    const { data } = await axios.get(apiUrl);

    if (!data.success || !data.result) {

      throw new Error("Aucune réponse obtenue.");

    }

    // Réponse stylisée

    const reply = `> Emry :

-Reponse: ${data.result}`;

    await sock.sendMessage(from, { text: reply }, { quoted: sentMsg });

  } catch (err) {

    console.error("❌ Erreur commande hades :", err);

    await sock.sendMessage(msg.key.remoteJid, {

      text: `> Knut MD:⚠️ Erreur : ${err.message}`

    }, { quoted: msg });

  }

}