export const name = "owner";

export async function execute(sock, msg, args) {
  const from = msg.key.remoteJid;

  // Texte principal
  const text = `╔═══•❥🌑•❥═══•❥🌑•❥═══╗
        ⚜️ 𝐊𝐍𝐔𝐓  𝐌𝐃 ⚜️
╚═══•❥🌑•❥═══•❥🌑•❥═══╝

╔══════•⊰👁️‍🗨️⊱•══════╗
     🕷️ 𝘿𝙀𝙑 𝘽𝙔 𝙆𝙉𝙐𝙏 🕷️
╚══════•⊰👁️‍🗨️⊱•══════╝

│ ⚫ *Rejoins la Confrérie KNUT MD* ⚫
│ 
│ 🖤  Knut : +237 683 939 081
│ 🖤. OMA : +237 6 92 42 27 54
│ 🖤 Telegram : [t.me/Devknut](https://t.me/Devknut)

╭─────•⊰ 🔮 Canaux Officiels 🔮 ⊱•─────╮
│ 🕯️ WhatsApp :  
│ https://whatsapp.com/channel/0029VbBezz33LdQaHgOdm22n  
│
│ 🕯️ Telegram :  
│ https://t.me/knutMDX  
╰━━━━━━━•⊰⚫⊱•━━━━━━━╯`;

  // Envoi du message
  await sock.sendMessage(from, { text }, { quoted: msg });
}