import fetch from "node-fetch";

export const name = "hentai";

export async function execute(sock, msg, args) {
  const from = msg.key.remoteJid;

  try {
    // Récupération aléatoire d'une vidéo depuis l'API
    const response = await fetch("https://apis-keith.vercel.app/dl/hentaivid");
    const data = await response.json();

    if (!data.status || !data.result || data.result.length === 0) {
      return await sock.sendMessage(from, {
        text: "> Knut MD:❌ Aucune vidéo trouvée pour le moment.",
      }, { quoted: msg });
    }

    // Sélection aléatoire d’une vidéo
    const video = data.result[Math.floor(Math.random() * data.result.length)];
    const { title, link, category, media, views_count } = video;
    const { video_url } = media;

    // Message stylisé KNUT MD
    const caption = 
`╔═══『 *KNUT MD 🔞 VIDÉO RANDOM* 』═══╗
║ 🎬 *Titre* : ${title}
║ 🧩 *Catégorie* : ${category}
║ 👁️ *Vues* : ${views_count}
║ 🌐 *Lien* : ${link}
╚════════════════════════════╝

💡 *Réponds par* ➜ "download"
pour télécharger la vidéo complète.

> Dev by Knut`;

    // Envoi du message principal avec la vidéo
    const sentMsg = await sock.sendMessage(from, {
      video: { url: video_url },
      caption: caption,
    }, { quoted: msg });

    const messageID = sentMsg.key.id;

    // Écoute des réponses au message
    sock.ev.on("messages.upsert", async (msgUpdate) => {
      const received = msgUpdate.messages[0];
      if (!received.message) return;

      const receivedText = (
        received.message.conversation ||
        received.message.extendedTextMessage?.text ||
        ""
      ).trim().toLowerCase();

      const replyTo = received.message.extendedTextMessage?.contextInfo?.stanzaId;
      const senderID = received.key.remoteJid;

      if (replyTo === messageID) {
        // Réaction à la réponse
        await sock.sendMessage(senderID, { react: { text: "⬇️", key: received.key } });

        if (receivedText === "download" || receivedText === "télécharger") {
          await sock.sendMessage(senderID, {
            video: { url: video_url },
            caption: `📥 *Téléchargement terminé :*\n🎬 ${title}\n\n> KNUT MD ⚜️`,
          }, { quoted: received });
        } else {
          await sock.sendMessage(senderID, {
            text: "> Knut MD: ⚠️ Réponse invalide.\nRéponds simplement par *download* pour télécharger la vidéo.",
          }, { quoted: received });
        }
      }
    });

  } catch (err) {
    console.error("Erreur hentavid :", err);
    await sock.sendMessage(from, {
      text: "> Knut MD:❌ Une erreur est survenue lors de la récupération ou du traitement de la vidéo.",
    }, { quoted: msg });
  }
}