// commands/warnadmin.js

import chalk from "chalk";

import { statusProtections } from "../protections.js";

export const name = "warnadmin";

export async function execute(sock, msg, args) {

  const from = msg.key.remoteJid;

  if (!args[0] || !["on", "off"].includes(args[0])) {

    await sock.sendMessage(from, {

      text: `_⚫KNUT MDX☠️:_ WarnAdmin est ${statusProtections.warnAdmin ? "activé" : "désactivé"}\nUsage : .warnadmin <on/off>`

    });

    return;

  }

  statusProtections.warnAdmin = args[0] === "on";

  await sock.sendMessage(from, {

    text: `> Knut MD : WarnAdmin ${args[0] === "on" ? "activé" : "désactivé"} !`

  });

}

// ------------------ Surveillance des promotions/rétrogradations ------------------

export function warnAdminListener(sock) {

  sock.ev.on("group-participants.update", async (update) => {

    if (!statusProtections.warnAdmin) return;

    const groupId = update.id;

    // Promotion

    if (update.action === "promote") {

      for (const participant of update.participants) {

        await sock.sendMessage(groupId, {

          text: `╭═══۞ KNUT MDX V2 ۞══╮\n` +
 `🌘 KNUT XMD 2.0 🖤\n` +
`╰═════════════════╯\n\n` +
`╭═══🛡️ WARN ADMIN 🛡️═══╮\n` +
`│ ⚠️ Attention !\n` +
`│ 👤 @${participant.split("@")[0]} a été promu administrateur.\n` +                  `╰════════════════════╯\n\n`+

                `> ⚛️ Dev by Knut 🌘`,

          mentions: [participant]

        });

        console.log(chalk.yellow(`[WARN-ADMIN] ${participant} a été promu dans ${groupId}`));

      }

    }

    // Rétrogradation

    if (update.action === "demote") {

      for (const participant of update.participants) {

        await sock.sendMessage(groupId, {

          text: `╭═════۞ KNUT MDX V2 ۞═════╮\n` +
   `🌘 KNUT XMD 2.0 🖤\n` +     `╰═════۞════════════╯\n\n` +
`╭═══🛡️ WARN ADMIN 🛡️═══╮\n` +
`│ ⚠️ Attention !\n` +
`│ 👤 @${participant.split("@")[0]} a été rétrogradé.\n` +                `╰════════════════════╯\n\n` +

                `> ⚛️ Dev by Knut 🌘`,

          mentions: [participant]

        });

        console.log(chalk.red(`[WARN-ADMIN] ${participant} a été rétrogradé dans ${groupId}`));

      }

    }

  });

}