import fetch from "node-fetch";

export default {
  name: "wikipedia",
  alias: ["wiki"],
  description: " Recherche des informations sur Wikipedia et traduit automatiquement.",
  category: "information",

  async execute(sock, msg, args) {
    try {
      const from = msg.key.remoteJid;

      if (!args[0]) {
        return await sock.sendMessage(from, {
          text: "> Knut MD:📖 Veuillez fournir un sujet à rechercher sur Wikipedia.\n\nExemple : `.wikipedia Albert Einstein`"
        });
      }

      const query = args.join(" ");
      await sock.sendMessage(from, { text: `🔎 Recherche de *${query}* sur Wikipedia...` });

      // Récupération depuis l’API Wikipedia externe
      const response = await fetch(
        `https://api.siputzx.my.id/api/s/wikipedia?query=${encodeURIComponent(query)}`
      );
      const data = await response.json();

      if (!data.status || !data.data) {
        return await sock.sendMessage(from, { text: "❌ Aucun résultat trouvé pour ta requête." });
      }

      const { wiki, thumb } = data.data;

      // 🔹 Traduction via l’API libre de Google
      const transResponse = await fetch(
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(wiki)}`
      );
      const transData = await transResponse.json();
      const translated = transData[0].map((s) => s[0]).join("");

      const message =
        `📖 *Wikipedia Result*\n\n` +
        `📝 *Query:* ${query}\n\n` +
        `${translated}`;

      if (thumb) {
        await sock.sendMessage(
          from,
          {
            image: { url: thumb },
            caption: message
          },
          { quoted: msg }
        );
      } else {
        await sock.sendMessage(from, { text: message }, { quoted: msg });
      }
    } catch (error) {
      console.error("Erreur Wikipedia:", error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ Une erreur est survenue : ${error.message}`
      });
    }
  }
};