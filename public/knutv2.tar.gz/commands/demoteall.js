export const name = "demoteall";

export async function execute(sock, msg, args) {

  const from = msg.key.remoteJid;

  // Vérifie si c’est un groupe

  if (!from.endsWith("@g.us")) {

    return await sock.sendMessage(from, { 

      text: "> Knut MD: Commande de groupe !" 

    }, { quoted: msg });

  }

  try {

    const groupMetadata = await sock.groupMetadata(from);

    const participants = groupMetadata.participants || [];

    // Identités utiles

    const botJid = (sock?.user?.id || sock?.user?.jid || "").split?.(":")?.[0] || "";

    const actor = msg.key.participant || msg.participant || msg.key.remoteJid;

    const owner = participants.find(p => p.admin === "superadmin")?.id || null;

    // Construire la liste des admins à rétrograder

    const toDemote = participants

      .filter(p => p.admin && p.id !== botJid && p.id !== owner && p.id !== actor)

      .map(p => p.id);

    if (toDemote.length === 0) {

      return await sock.sendMessage(from, { 

        text: "> Knut MD: Pas de membre(s) à rétrograder.*" 

      }, { quoted: msg });

    }

    // Rétrograder les admins sélectionnés

    await sock.groupParticipantsUpdate(from, toDemote, "demote");

    // Message stylé

    const demotedList = toDemote.map(jid => `💔 @${jid.split("@")[0]}`).join("\n");

    const confirmation = `

╭══⚔️ KNUT MDX ☠️═══╮
🔽 *Rétrogradation* 🔽
╰═════════════════╯
⚠️ Admin(s) rétrogradé(s) : ${demotedList}
🖤 Ordre donné par : @${actor.split("@")[0]}
`;

    await sock.sendMessage(from, { 

      text: confirmation, 

      mentions: [...toDemote, actor] 

    });

  } catch (err) {

    console.error("> Knut MD: Erreur demoteall :", err);

    await sock.sendMessage(from, { 

      text: "> Knut MD: *Erreur lors du demoteall." 

    }, { quoted: msg });

  }

}