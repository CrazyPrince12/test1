// commands/infosgroups.js

export const name = "infosgroups";

export async function execute(sock, msg, args) {

  const from = msg.key.remoteJid;

  if (!from.endsWith("@g.us")) {

    await sock.sendMessage(from, { text: "> Knut MD: Cette commande de groupe !" });

    return;

  }

  try {

    const metadata = await sock.groupMetadata(from);

    const groupName = metadata.subject;

    const participants = metadata.participants;

    const creationDate = metadata.creation;

    const owner = metadata.owner || null;

    // Administrateurs

    const admins = participants.filter(p => p.admin);

    const adminMentions = admins.map(a => `@${a.id.split("@")[0]} (Admin)`);

    // Nombre de membres

    const totalMembers = participants.length;

    // Membre le plus actif

    let mostActive = "Aucune donnée";

    let activeUser = null;

    const recentMsgs = sock.msgs?.[from] || [];

    if (recentMsgs.length > 0) {

      const activityCount = {};

      for (const m of recentMsgs) {

        const sender = m.key.participant || m.key.remoteJid;

        if (!activityCount[sender]) activityCount[sender] = 0;

        activityCount[sender]++;

      }

      const mostActiveId = Object.keys(activityCount).reduce((a, b) => activityCount[a] > activityCount[b] ? a : b);

      mostActive = `@${mostActiveId.split("@")[0]} (${activityCount[mostActiveId]} msgs)`;

      activeUser = mostActiveId;

    }

    // Créateur

    let creatorText;

    if (owner) {

      const creatorInGroup = participants.find(p => p.id === owner);

      creatorText = creatorInGroup ? `@${owner.split("@")[0]}` : "> Knut MD:⚠️ Createur du groupe absent ";

    } else {

      creatorText = "Non disponible";

    }

    // Construction du message au style Knut MDX V2

    let infoText = "";

    infoText += `╭═══۞ KNUT MD V2 ۞═══╮\n`;

    infoText += `🌘 KNUT MD 2.0 🖤\n`;

    infoText += `╰═════════════════╯\n\n`;

    infoText += `╭═══👹 INFOS DU GROUPE 👹═══╮\n`;

    infoText += `│ 📝 Nom du groupe : ${groupName}\n`;

    infoText += `│ 🛡️ Administrateurs : ${adminMentions.join(", ")}\n`;

    infoText += `│ 👥 Membres présents : ${totalMembers}\n`;

    infoText += `│ 🔥 Membre le plus actif : ${mostActive}\n`;

    infoText += `│ 📆 Date de création : ${new Date(creationDate * 1000).toLocaleString()}\n`;

    infoText += `│ 👑 Créateur : ${creatorText}\n`;

    infoText += `╰════════════════════╯\n`;

    infoText += `> Dev by Knut `;

    const mentions = [

      ...admins.map(a => a.id),

      ...(activeUser ? [activeUser] : []),

      ...(owner ? [owner] : [])

    ];

    await sock.sendMessage(from, { text: infoText, mentions });

  } catch (e) {

    console.error("Erreur InfosGroups:", e);

    await sock.sendMessage(from, { text: "> Knut MD: Récupération des informations impossible ." });

  }

}