import fetch from "node-fetch";

export default {
  name: "tik2",
  alias: ["tiktoks", "tiks"],
  description: "Recherche des vidéos TikTok par mot-clé",
  category: "tools",

  async execute(sock, msg, args) {
    try {
      const from = msg.key.remoteJid;

      if (!args[0]) {
        return await sock.sendMessage(from, {
          text: "> Knut MD: 🌸 Que veux-tu chercher sur TikTok ?\n\n*Exemple :* .tiktoksearch <mot-clé>"
        });
      }

      const query = args.join(" ");
      await sock.sendMessage(from, { text: `🔎 Recherche TikTok pour : *${query}*` });

      const response = await fetch(
        `https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=${encodeURIComponent(query)}`
      );
      const data = await response.json();

      if (!data || !data.data || data.data.length === 0) {
        return await sock.sendMessage(from, { text: "❌ Aucun résultat trouvé. Essaie un autre mot-clé." });
      }

      // Mélange et limite à 5 résultats maximum
      const results = data.data.sort(() => Math.random() - 0.5).slice(0, 5);

      for (const video of results) {
        const message =
          `🌸 *Résultat TikTok :*\n\n` +
          `*• Titre:* ${video.title}\n` +
          `*• Auteur:* ${video.author || "Inconnu"}\n` +
          `*• Durée:* ${video.duration || "Inconnue"}\n` +
          `*• Lien:* ${video.link}\n\n`;

        if (video.nowm) {
          await sock.sendMessage(
            from,
            {
              video: { url: video.nowm },
              caption: message
            },
            { quoted: msg }
          );
        } else {
          await sock.sendMessage(from, { text: `❌ Impossible d’obtenir la vidéo pour *${video.title}*.` });
        }

        // Délai léger pour éviter le flood
        await new Promise(res => setTimeout(res, 1200));
      }

      await sock.sendMessage(from, { text: "> Knut MD:✅ Recherche terminée avec succès !" });
    } catch (error) {
      console.error("Erreur TikTokSearch:", error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: "> Knut MD:❌ Une erreur est survenue lors de la recherche TikTok. Réessaie plus tard."
      });
    }
  }
};