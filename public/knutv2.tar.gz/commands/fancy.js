import axios from "axios";

export const name = "fancy";

export async function execute(sock, msg, args) {
  try {
    const from = msg.key.remoteJid;
    const text = args.join(" ").trim();

    // Vérification de saisie
    if (!text) {
      await sock.sendMessage(from, {
        text: `✍️ *Usage correct :*\n\n.fancy <texte>\n\n📌 *Exemple :* .fancy Knut MD`
      }, { quoted: msg });
      return;
    }

    // Appel de l'API externe
    const apiUrl = `https://www.dark-yasiya-api.site/other/font?text=${encodeURIComponent(text)}`;
    const response = await axios.get(apiUrl);

    if (!response.data.status || !response.data.result) {
      await sock.sendMessage(from, {
        text: "> Knut MD:⚠️ *Erreur :* impossible d'obtenir les polices. Réessayez plus tard."
      }, { quoted: msg });
      return;
    }

    // Mise en forme des résultats
    const fonts = response.data.result
      .map(item => `🔸 *${item.name}*\n${item.result}`)
      .join("\n\n");

    const resultText = `╭═════ஜ۩۞۩ஜ═════╮
✨ *FANCY FONT GENERATOR* ✨
╰═════ஜ۩۞۩ஜ═════╯

${fonts}

> Dev by Knut`;

    // Réaction 🐺 avant la réponse
    await sock.sendMessage(from, { react: { text: "🐺", key: msg.key } });

    // Envoi du résultat
    await sock.sendMessage(from, { text: resultText }, { quoted: msg });

  } catch (error) {
    console.error("❌ Erreur fancy :", error);
    await sock.sendMessage(msg.key.remoteJid, {
      text: "> Knut MD:⚠️ Une erreur est survenue lors de la génération des polices."
    }, { quoted: msg });
  }
}