import fetch from 'node-fetch';

export const name = "xvid";

export async function execute(sock, msg, args, { usedPrefix, lann }) {
    const from = msg.key.remoteJid;
    const text = args.join(' ').trim();

    if (!text) {
        return await sock.sendMessage(from, {
            text: `> ⚠️ KNUT MD: Exemple d'utilisation: .xvid Mia khalifa`
        }, { quoted: msg });
    }

    try {
        // Requête API
        const response = await fetch(
            `https://api.betabotz.eu.org/api/search/xnxx?query=${encodeURIComponent(text)}&apikey=${lann}`
        );
        const data = await response.json();

        const results = data.result;
        if (!results || results.length === 0) {
            return await sock.sendMessage(from, {
                text: `> ⚠️ KNUT MD: Aucun résultat trouvé pour "${text}".`
            }, { quoted: msg });
        }

        // Construire le texte de réponse
        let teks = `> ╭════۩۞۩════╮\n> 🔍 KNUT MD - XNXX SEARCH\n> ╰════۩۞۩════╯\n\n`;
        teks += `🔑 *Mots-clés*: ${text}\n\n`;

        results.forEach((item, index) => {
            teks += `📑 *No* : ${index + 1}\n`;
            teks += `📚 *Titre* : ${item.title}\n`;
            teks += `⏱️ *Durée* : ${item.duration}\n`;
            teks += `🔗 *URL* : ${item.link}\n`;
            teks += `─────────────────\n`;
        });

        // Réaction au message
        await sock.sendMessage(from, { react: { text: '⏱️', key: msg.key } });

        // Envoyer le premier résultat avec vignette
        await sock.sendMessage(from, {
            image: { url: results[0].thumb },
            caption: teks
        }, { quoted: msg });

    } catch (err) {
        console.error("❌ XNXX Search Error:", err);
        await sock.sendMessage(from, {
            text: `⚠️ KNUT MD: Impossible de récupérer les données.\nRaison: ${err.message || 'Erreur inconnue'}`
        }, { quoted: msg });
    }
}