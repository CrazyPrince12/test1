export const name = "listonline";

export async function execute(sock, msg) {
    const from = msg.key.remoteJid;

    try {
        // Récupération des infos du groupe
        const groupMeta = await sock.groupMetadata(from);
        if (!groupMeta?.participants) throw new Error("Impossible de récupérer les participants du groupe.");

        // Assurez-vous que sock.chats est défini
        const chats = sock.chats || {};

        // Filtrage des participants en ligne
        const online = Object.entries(chats)
            .filter(
                ([jid, chat]) =>
                    jid.endsWith("@s.whatsapp.net") &&
                    chat?.presences &&
                    groupMeta.participants.some((p) => jid.startsWith(p.id))
            )
            .sort((a, b) => a[0].localeCompare(b[0], "id", { sensitivity: "base" }))
            .map(([jid], i) => `*${i + 1}.* @${jid.split("@")[0]}`)
            .join("\n");

        const text = `> ╭════۩۞۩════╮
> 👤 KNUT MD - LIST ONLINE
> ╰════۩۞۩════╯
<==================>
${online || "Aucun membre en ligne."}`;

        await sock.sendMessage(from, { text: text }, { quoted: msg });

    } catch (err) {
        console.error("❌ ListOnline Error:", err);
        await sock.sendMessage(from, {
            text: `> ⚠️ KNUT MD: Impossible de récupérer la liste des membres en ligne.\nRaison: ${err.message || 'Erreur inconnue'}`
        }, { quoted: msg });
    }
}