import { downloadMediaMessage } from "@whiskeysockets/baileys";
import sharp from "sharp";

export const name = "blur";

export async function execute(sock, msg, args) {
  const from = msg.key.remoteJid;

  try {
    let imageBuffer;

    // Vérifie si l'image est citée ou dans le message
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const hasImage = msg.message?.imageMessage;

    if (quoted?.imageMessage) {
      imageBuffer = await downloadMediaMessage(
        { message: { imageMessage: quoted.imageMessage } },
        "buffer",
        {},
        {}
      );
    } else if (hasImage) {
      imageBuffer = await downloadMediaMessage(msg, "buffer", {}, {});
    } else {
      await sock.sendMessage(
        from,
        {
          text: "> Knut MD: ❌ *Réponds à une image ou envoie une image avec la légende .blur*",
        },
        { quoted: msg }
      );
      return;
    }

    // Redimensionnement et optimisation
    const resizedImage = await sharp(imageBuffer)
      .resize(800, 800, {
        fit: "inside",
        withoutEnlargement: true,
      })
      .jpeg({ quality: 80 })
      .toBuffer();

    // Application de l’effet flou
    const blurredImage = await sharp(resizedImage).blur(10).toBuffer();

    // Envoi de l'image floutée
    await sock.sendMessage(
      from,
      {
        image: blurredImage,
        caption: `╭════۩۞۩════╮
⚫ *KNUT MD* ⚫
╰════۩۞۩════╯
🪞 *Image floutée avec succès !* ✨`,
      },
      { quoted: msg }
    );
  } catch (error) {
    console.error("❌ Erreur dans blur :", error);
    await sock.sendMessage(
      from,
      {
        text: "> Knut MD:⚠️ *Impossible d’appliquer le flou.* Réessaie plus tard.",
      },
      { quoted: msg }
    );
  }
}