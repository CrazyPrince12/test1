export const name = "autorecording";

export const description = "Active/Désactive l'autorecording (bot fait comme s'il enregistrait un audio).";

export const usage = "!autorecording <on/off>";

let autoRecording = false; // état par défaut

export function isAutoRecording() {

  return autoRecording;

}

export async function execute(sock, msg, args) {

  const from = msg.key.remoteJid;

  if (!args[0] || !["on", "off"].includes(args[0])) {

    await sock.sendMessage(from, { text: "⚠️ Utilisation : !autorecording <on/off>" });

    return;

  }

  autoRecording = args[0] === "on";

  await sock.sendMessage(from, {

    text: `🎙️ Autorecording ${autoRecording ? "activé ✅" : "désactivé ❌"}`

  });

}