export const name = "tagall";

export async function execute(sock, msg, args) {

  try {

    const groupMetadata = await sock.groupMetadata(msg.key.remoteJid);

    const participants = groupMetadata.participants;

    const mentions = participants.map(p => p.id);

    // Décoration des mentions avec 🖤

    const decoratedMentions = participants

      .map(p => `🖤 @${p.id.split("@")[0]}`)

      .join("\n");

    // =================== TEXTE KNUT MDX DRAMATIQUE ===================

    const dramaticText = `╭══۞ KNUT MDX V2 ۞══╮
    🖤🐺TAGALL🐺🖤
╰═════════════════╯`;

    await sock.sendMessage(msg.key.remoteJid, {

      image: { url: "https://files.catbox.moe/86pqoz.jpg" },
 caption:`\n\n${dramaticText}\n${decoratedMentions}`,

      mentions

    });

  } catch (err) {

    console.error("_⚫KNUT MDX☠️:_ ❌ Erreur tagall :", err);

  }

}